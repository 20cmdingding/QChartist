package Hello;

# This package (and file) is used by 40-par-hashref.t
use strict;
sub hello {
    return();
}

1;
